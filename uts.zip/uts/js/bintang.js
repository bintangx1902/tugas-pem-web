function googleTranslateElementInit() {
    new google.translate.TranslateElement({
        pageLanguage: 'id'
    }, 'google_translate_element');
}